<template>
    <header>
    <h1>Aqui puedes agregar una nueva actividad 😁</h1>
    <div class="optionEditar">
        <p>si deseas editar una actividad haz click en el boton</p>
        <q-btn to="/editar">Editar</q-btn>
    </div>
</header>
    
        <main>
            <div class="q-pa-md" >

<q-form
  @submit="onSubmit"
  @reset="onReset"
  class="q-gutter-md"
>
  <q-input  
    type="textarea"
    filled
    v-model="descriptionActivity"
    label="descripcion de la actividad "
    lazy-rules
  />

  <q-input
    filled
    type="date"
    v-model="date"
    label="Your age *"
    lazy-rules
  />

  <q-toggle v-model="accept" label="I accept the license and terms" />

  <div>
    <q-btn label="Submit" type="submit" color="primary"/>
    <q-btn label="Reset" type="reset" color="primary" flat class="q-ml-sm" />
  </div>
</q-form>

</div>
        </main>
  


</template>


<style src="../styles//agregar.css" scoped></style>

<script>
import { useQuasar } from 'quasar'
import { ref } from 'vue'

export default {
  setup () {
    const $q = useQuasar()

    const descriptionActivity = ref(null)
    const date = ref(null)
    const accept = ref(false)

    return {
      descriptionActivity,
      date,
      accept,

      onSubmit () {
        if (accept.value !== true) {
          $q.notify({
            color: 'red-5',
            textColor: 'white',
            icon: 'warning',
            message: 'You need to accept the license and terms first'
          })
        }
        else {
          $q.notify({
            color: 'green-4',
            textColor: 'white',
            icon: 'cloud_done',
            message: 'Submitted'
          })
        }
      },

      onReset () {
        descriptionActivity.value = null
        date.value = null
        accept.value = false
      }
    }
  }
}




</script>