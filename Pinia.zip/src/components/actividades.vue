<template>
   <header>
    <h1>Aqui estan tus actividades</h1>
    <div class="option">
        <p>tambien puedes agregar una nueva aqui</p>
        <q-btn to="/">agregar</q-btn>
    </div>
   </header>
</template>

<style src="../styles/actividades.css" scoped></style>